package org.openshift.parks.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/ws")
public class JaxrsConfig extends Application{

}
